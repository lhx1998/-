import poplib
import email
import datetime
import time
import os
from email.parser import Parser
from email.header import decode_header
from email.utils import parseaddr

pop3_server = r'pop.163.com' 
mail_user = r'18397381785@163.com' 
mail_passwd = r'lhx88888888'

# 字符编码转换
def decode_str(s):
    value, charset = decode_header(s)[0]
    if charset:
        value = value.decode(charset)
    return value

# 下载附件
name_list  = set()
def download_att(msg):
    attachment_files = []
    global mylist
    global name_list
    mydir_path = ".\\homework\\" + myemail
    for part in msg.walk():
        file_name = part.get_filename() # 获取附件名称类型
        contType = part.get_content_type()
        
        if file_name:
            h = email.header.Header(file_name)
            dh = email.header.decode_header(h)  # 对附件名进行解码
            filename = dh[0][0]

            if dh[0][1]:
                filename = decode_str(str(filename, dh[0][1])) # 附件名称可读化
 
            # 判断邮件格式是否正确
            temp_list = filename.split("_")
            if len(temp_list) == 3:
                 if temp_list[0] == myemail and temp_list[1] in mylist:
                     # 显示文件名
                    print(filename)
                    name_list.add(filename)
                    #创建目录
                    is_dir_exit = os.path.exists(mydir_path)
                    if not is_dir_exit:
                        os.mkdir(mydir_path) 
                     # 附件数据
                    data = part.get_payload(decode = True)
                    att_file = open(mydir_path + "\\" + filename, "wb")
                    att_file.write(data)
                    att_file.close()
 
    return attachment_files

# 通过输入来判断邮箱
mydict = {}
myemail = "temp"
mylist = []
def judge_email():
    global pop3_server
    global mail_user
    global mail_passwd
    global mydict
    global myemail
    global mylist 
    count = 0
    myemail = input("please input(example:NR1023):\n")
    myfile = open(".\\mails\\" + myemail + ".txt", "r")
    mylines  = myfile.readlines()
    # 处理字符串加到字典中
    for line in mylines:
        mytemp1 = line.split('#')
        mytemp = mytemp1[0].split('=')
        if mytemp[0] == '\n':
            count += 1
            if count == 1:   
                continue
            if count == 2:
                break
          
        if len(mytemp) == 1:
            mylist.append(mytemp[0])  
        if len(mytemp) == 2:
            mydict[mytemp[0]] = mytemp[1].strip('?')
                
    # 去掉student列表中的\n等
    i = 0
    for list in mylist:
        mylist[i] = list.strip()
        i += 1
    
    mydict['student'] = mylist
  
    pop3_server = mydict["pop3_server"]
    mail_user = mydict["mail_user"]
    mail_passwd = mydict["mail_passwd"]

#产生违纪名单
def creat_illegal_list():
    i = 0
    temp_list = []
    for name in name_list:
        if '_' in name:
            temp = name.split('_')
            temp_list.append(temp[1])
            i += 1
    print("已交名单:")
    print(temp_list)
    illegal_name = []
    illegal_name = mydict["student"]
    for name in temp_list:
        if name in illegal_name:
            illegal_name.remove(name)
    print("未交名单:")
    print(illegal_name)
        
# 登录邮箱
def log_in():
    global pop3_server
    global mail_user
    global mail_passwd
    # connect to server
    server = poplib.POP3_SSL(pop3_server)
    
    # 调试信息级别，0为无信息，1为中等，2为最多
    server.set_debuglevel(1)

    # 打印POP3服务器的欢迎文字
    print(server.getwelcome().decode('utf-8'))

    # 身份认证
    server.user(mail_user)
    server.pass_(mail_passwd)
    
    # 拿邮件数目
    resp, mails, octets = server.list()
    index = len(mails)

    # 拿最新的50封
    for i in range(index, index - 50, -1):
        resp, lines, octets = server.retr(i)
        # lines存储了邮件的原始文本的每一行
        
        # 邮件的原始文本
        msg_content = b'\r\n'.join(lines).decode('utf-8')
       
        # 解析邮件
        msg = Parser().parsestr(msg_content)
        
        date1 = time.strptime(msg.get("Date")[0:24], '%a, %d %b %Y %H:%M:%S')
        now=datetime.datetime.now() # .strftime('%a, %d %b %Y %H:%M:%S')
        lastday1=now-datetime.timedelta(days=1,hours=0,minutes=0,seconds=0,\
        microseconds=0) # 前一天
        
        lastday2=now-datetime.timedelta(days=0,hours=1,minutes=30,seconds=0,\
        microseconds=0) # 最后的时间
        # 邮件时间格式转换
        date2 = time.strftime("%Y-%m-%d-%H-%M",date1)
        start_time = lastday1.strftime("%Y-%m-%d-%H-%M") # 前一天的时间
        end_time = lastday2.strftime("%Y-%m-%d-%H-%M") # 最后的时间

        if date2 > start_time and date2 < end_time: 
            download_att(msg)


     
    # 记得断开连接
    server.quit()

if __name__ == "__main__":
    judge_email() 
    log_in()
    creat_illegal_list()
   

    
    
