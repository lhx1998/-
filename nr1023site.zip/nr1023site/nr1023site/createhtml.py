import os

def creat_html(classid):
    class_name = classid

    root_dir = ".\\static\\homework\\" + class_name
    mytemplate = '''
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>邮件下载页面</title>

{cat}
<link href="http://127.0.0.1:8000/static/css/rotateword.css" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="http://127.0.0.1:8000/static/js/jquery-1.3.2.min.js"></script>
<script type="text/javascript" src="http://127.0.0.1:8000/static/js/rotate.js"></script>
<script type="text/javascript">
$(document).ready(function()
{script}
);
</script>
</head>
<body>


<div id="wrap">
         <h1>点击下载邮件</h1>
        <div id="flip_menu1">
        {yourcontent}
</div>

<h1>已交名单</h1>
<h1>{finish}</h1>
<h1>未交名单</h1>
<h1>{unfinish}</h1>
</body>
<html>
    '''
    strcontent = ""

    for dir, dirs, files in os.walk(root_dir):
        str_a_label = '''<div><a href = "http://127.0.0.1:8000/static/homework/{}/%s">%s</a></div>'''
        str_a_label = str_a_label.format(classid)
        for filename in files:
            strcontent += str_a_label % (filename, filename)
        break
    myscript = '{var menu1 = new Flipmenu("flip_menu1"); \
       var menu2 = new Flipmenu("flip_menu2");}'

    mycat = '''
    
<link rel="stylesheet" href="http://127.0.0.1:8000/static/css/cat.css" media="screen" type="text/css"/>
</head>
<body><script src="/demos/googlegg.js"></script>
<div class="cat">
<div class="head_content">
	<div class="ear_left"></div>
	<div class="ear_right"></div>
	<div class="head"></div>
	<div class="brow_left"></div>
	<div class="brow_right"></div>
	<div class="eye_left">
		<div id="pL" class="pupil"></div>
	</div>
	<div class="eye_right">
		<div id="pR" class="pupil"></div>
	</div>
	<div class="beard_left1"></div>
	<div class="beard_left2"></div>
	<div class="beard_left3"></div>
	<div class="beard_right1"></div>
	<div class="beard_right2"></div>
	<div class="beard_right3"></div>
	<div class="nose"></div>
	<div class="mouse">
		<div class="mouse_top"></div>
		<div class="mouse_left"></div>
		<div class="mouse_right"></div>
		<div class="mouse_bottom"></div>
		<div class="mouse_bottom_show"></div>
		<div class="miao">喵</div>
	</div>
</div>
<div class="body_content">
	<div class="body"></div>
	<div class="arm_left"></div>
	<div class="arm_right"></div>
	<div class="leg_left"></div>
	<div class="leg_right"></div>
	<div class="tail">
		<div class="tail1"></div>
		<div class="tail2"></div>
		<div class="tail3"></div>
	</div>
</div>
</div>


<script>
//获取cat所在div的位置
var catx=document.getElementsByClassName("cat")[0].offsetLeft;
var pL=document.getElementById("pL");
var pR=document.getElementById("pR");
var r=17;

document.onmousemove=function(ev) {
	var e = ev || event;
	var m=[];
	m.x=e.clientX-catx;  //鼠标坐标能落在左边等位置
	m.y=e.clientY-170;   //head_content、head、eye离上方的距离，使鼠标能落在上方区域
	var s=[];
	s.x=pL.offsetLeft;
	s.y=pL.offsetTop;
	var mosx = Math.abs(m.x - s.x);
	var mosy = Math.abs(m.y - s.y);
	var angle = Math.atan(mosy / mosx);
	var cx = 0, cy = 0;
	if (m.x >= s.x && m.y <= s.y) {
		cx = Math.cos(angle) * r;
		cy = Math.sin(angle) * -r;
//            console.log("右下");
	}
	if (m.x < s.x && m.y < s.y) {
		cx = Math.cos(angle) * -r;
		cy = Math.sin(angle) * -r;
//            console.log("左下");
	}
	if (m.x < s.x && m.y > s.y) {
		cx = Math.cos(angle) * -r;
		cy = Math.sin(angle) * r;
//            console.log("左上");
	}
	if (m.x > s.x && m.y > s.y) {
		cx = Math.cos(angle) * r;
		cy = Math.sin(angle) * r;
//            console.log("右上");
	}

	if((m.x+catx)>=catx && (m.x+catx)<=(catx+345) && (m.y+170)>=100 && (m.y+170)<=360){
		pL.style.top =15+'px';
		pR.style.top =15+'px';
		pL.style.left =18+'px';
		pR.style.left =18+'px';
	}else{
		pL.style.top = 15+ cy + 'px';
		pR.style.top = 15+ cy + 'px';
		pL.style.left =17+cx + 'px';
		pR.style.left =17+cx + 'px';
	}
}
</script>

    '''
    myfile1 = open(".//namelist//"+class_name+"//"+"finishname.txt", 'r')
    str_finish = myfile1.read()
    myfile1.close()
    myfile2 = open(".//namelist//"+class_name+"//"+"unfinishname.txt", 'r')
    str_unfinish = myfile2.read()
    myfile2.close()
    mydict = {'yourcontent':strcontent} 
    mytemplate = mytemplate.format(cat = mycat, script = myscript, yourcontent = mydict['yourcontent'], 
	finish = str_finish, unfinish = str_unfinish)
    return mytemplate
    


if __name__ == "__main__":
    pass
    
    