from django.http import HttpResponse
from django.shortcuts import render

from .loademail import *
from .createhtml import *

def downemail(request, classid):
    # 登录邮箱进行下载
    judge_email(classid) 
    log_in()
    creat_illegal_list(classid)    

    # 利用模板生成不同班级的html
    class_name = classid
    root_dir = ".\\static\\homework\\" + class_name
    strcontent = ""
    for dir, dirs, files in os.walk(root_dir):
        str_a_label = '''<div><a href = "http://127.0.0.1:8000/static/homework/{}/%s">%s</a></div>'''
        str_a_label = str_a_label.format(class_name)

        for filename in files:
            strcontent += str_a_label % (filename, filename)
        break
        
    myfile1 = open(".//namelist//"+class_name+"//"+"finishname.txt", 'r')
    str_finish = myfile1.read()
    myfile1.close()
    myfile2 = open(".//namelist//"+class_name+"//"+"unfinishname.txt", 'r')
    str_unfinish = myfile2.read()
    myfile2.close()
    mycontent = {'yourcontent': strcontent,'finish':str_finish, 'unfinish':str_unfinish}
    return render(request, "cat.html", context = mycontent)


def start(request):
    # 主页的html
    dir_path = ".\\mails"
    strcontent = ""
    for dir, dirs, files in os.walk(dir_path):
        str_a_label ='''<a href="http://127.0.0.1:8000/class/%s" target="_blank">%s</a>'''
        for filename in files:
            temp = filename.split(".")
            filename = temp[0]
            strcontent += str_a_label % (filename, filename)
        break
    
    myfile = open(".//static//downloadsystem.html", "r", encoding='UTF-8')
    mytext = myfile.read()
    mytext = mytext.format(classname = strcontent)

    return HttpResponse(mytext)


def sayhi(request, name, age):   
    mycontent = {'name': name, 'age' :age}
    return render(request, "sayhi.html", context = mycontent)

